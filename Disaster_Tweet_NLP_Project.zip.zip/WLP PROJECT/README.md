# NLP Project for Disaster Tweet Classification
**Submission Date:** October 15, 2026

## 1. Project Background & Challenge
In modern digital emergency management, social media platforms like Twitter serve as vital channels for real-time crisis communication. However, manually separating genuine emergency alerts from casual, metaphorical language (e.g., "This test was a total disaster!") is a major operational challenge. This project develops an automated Natural Language Processing (NLP) pipeline to accurately classify tweets into real-time disaster alerts (`1`) or normal context (`0`).

## 2. Dataset Overview & Exploration
The system uses a dataset of hand-classified tweets containing structural attributes: `id`, `keyword`, `location`, `text`, and `target`. 
- **Pre-processing Protocol:** Raw text data is normalized to lowercase, and structural noise—including hyperlink URLs, punctuation, special symbols, and numbers—is stripped out via regular expressions (`re`) to ensure vocabulary consistency.

## 3. Feature Engineering & Model Selection
- **Feature Extraction:** Words are converted into numerical features using a **TF-IDF Vectorizer** (Term Frequency-Inverse Document Frequency) limited to the top 5,000 features, filtering out standard English stop words.
- **Model Training:** The engineered feature matrix is split into an **80% training set** and a **20% validation set**. A **Logistic Regression** classifier is selected and trained on the data, offering optimal execution efficiency and high text classification precision.

## 4. Pipeline Evaluation Performance
Upon evaluating the model against unseen test data, the text classification pipeline demonstrates solid convergence metrics:
- **Core Accuracy:** Balanced prediction rate across both classes.
- **Precision:** High baseline targeting to minimize false emergency alarms.

## 5. Deployment & System Architecture
The application architecture is structured into a localized production state:
1. `train.py`: Handles data processing, feature transformation engineering, and serialized model saving.
2. `disaster_model.pkl` & `tfidf_vectorizer.pkl`: The serialized pipeline configuration artifacts.
3. `app.py`: A lightweight Flask production server loading the saved brains to host a responsive, single-page web interface dashboard utilizing asynchronous JavaScript (`fetch`).

## 6. How to Run the Project
Ensure dependencies are satisfied:
```bash
pip install flask scikit-learn numpy pandas
```
Execute the pipeline sequentially:
```bash
python train.py
python app.py
```
Open your browser and navigate to `http://127.0.0` to test live tweets on the dashboard interface.
