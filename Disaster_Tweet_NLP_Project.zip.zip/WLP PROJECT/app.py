from flask import Flask, request, jsonify, render_template_string
import pickle

app = Flask(__name__)

# Load serialized brains
with open('disaster_model.pkl', 'rb') as f:
    model = pickle.load(f)
with open('tfidf_vectorizer.pkl', 'rb') as f:
    vectorizer = pickle.load(f)

HTML_INTELLIGENCE_LAYOUT = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Disaster Tweet Intelligence Dashboard</title>
    <link href="https://jsdelivr.net" rel="stylesheet">
    <style>
        :root { --disaster-bg: #fff5f5; --disaster-border: #feb2b2; --disaster-text: #9b2c2c;
                --normal-bg: #f0fff4; --normal-border: #c6f6d5; --normal-text: #22543d; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background-color: #f4f6f9; }
        .dashboard-header { background-color: #1e2229; color: #fff; padding: 18px 0; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .card { border: none; border-radius: 12px; box-shadow: 0 8px 16px rgba(0,0,0,0.04); background: #fff; padding: 30px; }
        .btn-primary { background-color: #0d6efd; border: none; padding: 14px; font-weight: bold; border-radius: 8px; width: 100%; transition: 0.2s ease; }
        .btn-primary:hover { background-color: #0b5ed7; transform: translateY(-1px); }
        .alert-disaster { background-color: var(--disaster-bg); border: 1px solid var(--disaster-border); color: var(--disaster-text); }
        .alert-normal { background-color: var(--normal-bg); border: 1px solid var(--normal-border); color: var(--normal-text); }
        .metric-box { background-color: #f8f9fa; border-radius: 8px; padding: 15px; text-align: center; border: 1px solid #e9ecef; }
    </style>
</head>
<body>
    <div class="dashboard-header">
        <div class="container d-flex justify-content-between align-items-center">
            <h4 class="mb-0">📊 Disaster Tweet Intelligence Dashboard</h4>
            <span class="badge bg-success py-2 px-3">NLP Production Engine Status: Active</span>
        </div>
    </div>
    <div class="container my-5">
        <div class="row g-4">
            <div class="col-md-7">
                <div class="card">
                    <h5 class="mb-3 text-primary">📥 Real-Time Threat Assessment Input</h5>
                    <p class="text-muted small">Input unstructured tweet parameters below. The underlying natural language validation grid automatically maps feature tokens to detect valid crisis alerts.</p>
                    <form id="predictionForm">
                        <div class="mb-3">
                            <textarea class="form-control" id="tweetText" rows="6" placeholder="Paste tweet string data here (e.g., 'Wildfires burning uncontrollably over California county roads...')" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary" id="submitBtn">⚡ Classify Intent Vector</button>
                    </form>
                </div>
            </div>
            <div class="col-md-5">
                <div class="card d-flex flex-column justify-content-between" style="min-height: 380px;">
                    <div>
                        <h5 class="mb-4 text-secondary">🔍 Engine Inference Output</h5>
                        <div id="resultDisplay" class="text-center py-5">
                            <p class="text-muted italic">Awaiting semantic string input from feature gateway...</p>
                        </div>
                    </div>
                    <div class="border-top pt-4">
                        <h6 class="fw-bold small text-uppercase text-muted mb-3">Mathematical Engine Configurations</h6>
                        <div class="row g-2">
                            <div class="col-6"><div class="metric-box"><div class="small text-muted">Classifier</div><div class="fw-bold text-dark text-truncate">Logistic Regression</div></div></div>
                            <div class="col-6"><div class="metric-box"><div class="small text-muted">Feature Model</div><div class="fw-bold text-dark">TF-IDF Vector</div></div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('predictionForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const tweetText = document.getElementById('tweetText').value;
            const resultDisplay = document.getElementById('resultDisplay');
            const submitBtn = document.getElementById('submitBtn');
            
            submitBtn.disabled = true;
            resultDisplay.innerHTML = '<div class="spinner-border text-primary my-2" role="status"></div><p class="text-muted small">Computing token probabilities...</p>';

            try {
                const response = await fetch('/predict', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tweet: tweetText })
                });
                const data = await response.json();
                const isDisaster = data.result.includes("Disaster");
                const alertClass = isDisaster ? "alert-disaster" : "alert-normal";
                
                resultDisplay.innerHTML = `
                    <div class="alert \${alertClass} p-4 rounded-3 shadow-sm border-0 animate-fade-in">
                        <h2 class="mb-2">\${isDisaster ? "🚨" : "✅"}</h2>
                        <h5 class="fw-bold mb-0">\${data.result}</h5>
                        <div class="small text-muted mt-3 pt-2 border-top">Processed String Dimension: <strong>\${tweetText.length}</strong> bytes.</div>
                    </div>
                `;
            } catch (error) {
                resultDisplay.innerHTML = '<div class="alert alert-danger">API Endpoint Mapping Interrupted. Ensure Flask context is active.</div>';
            } finally {
                submitBtn.disabled = false;
                submitBtn.innerHTML = "⚡ Classify Intent Vector";
            }
        });
    </script>
</body>
</html>
"""

@app.route('/')
def home():
    return render_template_string(HTML_INTELLIGENCE_LAYOUT)

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    raw_tweet = data.get('tweet', '')
    vectorized_tweet = vectorizer.transform([raw_tweet.lower()])
    prediction = model.predict(vectorized_tweet)
    result = "Real Disaster Incident Alert" if prediction == 1 else "Normal Non-Disaster Context"
    return jsonify({'result': result})

app.run(debug=True, port=5000)

